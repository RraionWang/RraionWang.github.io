#ifndef XIAO_PINDEF_H
#define XIAO_PINDEF_H

/**
 * @file xiao_pindef.h
 * @brief Pin definitions for Seeed Xiao ESP32-S3 development board.
 * @author Rraion
 * @date 2025/5/29
 */

// Digital pin mappings for Seeed Xiao ESP32-S3
#define XIAO_ESP32S3_D0 1
#define XIAO_ESP32S3_D1 2
#define XIAO_ESP32S3_D2 3
#define XIAO_ESP32S3_D3 4
#define XIAO_ESP32S3_D4 5
#define XIAO_ESP32S3_D5 6
#define XIAO_ESP32S3_D6 43
#define XIAO_ESP32S3_D7 44
#define XIAO_ESP32S3_D8 7
#define XIAO_ESP32S3_D9 8
#define XIAO_ESP32S3_D10 9
#define XIAO_ESP32S3_D11 42
#define XIAO_ESP32S3_D12 41

#endif // XIAO_PINDEF_H